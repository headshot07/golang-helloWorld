package com.test.jobportal;

public class JobPortalMainApplication {
    public static void main(String[] args){

    }
}
