package com.test.jobportal.service;

import com.test.jobportal.controller.JobController;
import com.test.jobportal.model.Job;
import com.test.jobportal.model.User;

import java.util.ArrayList;

public class JobPortal {
    public ArrayList<Job> jobs;
    public JobController jobController;
    User user;

    public JobPortal(User user){
        jobs = new ArrayList<>();
        jobController = new JobController();
        this.user = user;
    }

    public boolean createJob(int id, String companyName, String jobTitle, String location, ArrayList<String> skills, String description, String department) {
        if(user.getType().equals("user"))
            return false;
        Job job = jobController.createJob(id, companyName, jobTitle, location, skills, description, department);
        jobs.add(job);
        return true;
    }

    public ArrayList<Job> searchJobsByLocation(String location) {
        ArrayList<Job> result = new ArrayList<>();
        for (Job job : jobs) {
            if (job.getLocation().equals(location)) {
                result.add(job);
            }
        }
        return result;
    }

    public Job searchJobsById(int id) {
        for (Job job : jobs) {
            if (job.getId() == id) {
                return job;
            }
        }
        return null;
    }

    public ArrayList<Job> searchJobBySkills(String[] skills) {
        ArrayList<Job> result = new ArrayList<>();
        for (int i = 0; i < skills.length; i++) {
            for(Job job : jobs) {
                if(job.getSkills().contains(skills[i])){
                    result.add(job);
                }
            }
        }
        return result;
    }
    public ArrayList<Job> searchJobsByDepartment(String department){
        ArrayList<Job> result = new ArrayList<>();
        for (Job job : jobs) {
            if (job.getDepartment().equals(department)) {
                result.add(job);
            }
        }
        return result;
    }
}
