package com.test.jobportal.model;

import org.checkerframework.checker.units.qual.A;

import java.util.ArrayList;
import java.util.SplittableRandom;

public class Job {
    private int id;
    private String companyName;
    private String jobTitle;
    private String location;
    private ArrayList<String> skills;
    private String description;
    private String department;

    public Job(int id, String companyName, String jobTitle, String location, ArrayList<String> skills, String description, String department) {
        this.id = id;
        this.location = location;
        this.jobTitle = jobTitle;
        this.companyName = companyName;
        this.skills = skills;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public ArrayList<String> getSkills() {
        return skills;
    }

    public String getLocation() {
        return location;
    }
    public String getDepartment(){
        return department;
    }
}
