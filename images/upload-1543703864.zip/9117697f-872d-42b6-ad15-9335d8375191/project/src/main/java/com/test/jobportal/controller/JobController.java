package com.test.jobportal.controller;

import com.test.jobportal.model.Job;

import java.util.ArrayList;

public class JobController {
    public Job createJob(int id, String companyName, String jobTitle, String location, ArrayList<String> skills, String description, String department) {
        Job job = new Job(id, companyName, jobTitle, location, skills, description, department);
        return job;
    }
}
