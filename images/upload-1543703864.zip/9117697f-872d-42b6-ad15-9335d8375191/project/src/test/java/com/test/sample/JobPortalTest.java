package com.test.sample;

import com.test.jobportal.model.Job;
import com.test.jobportal.model.User;
import com.test.jobportal.service.JobPortal;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class JobPortalTest {
    @Test
    void testJobCreation() {
        User user = new User(1, "Sanjay", "recruiter");
        JobPortal jobPortal = new JobPortal(user);
        ArrayList<String> skills = new ArrayList<>();
        skills.add("Java");
        skills.add("Python");
        int sizeBefore = jobPortal.jobs.size();
        boolean result = jobPortal.createJob(1,"Gaussb", "SDE", "Bengaluru", skills, "Amazing Job","Engineering");
        int sizeAfter = jobPortal.jobs.size();
        assertNotEquals(sizeBefore,sizeAfter);
    }
    @Test
    void testSearchJobById(){
        User user = new User(1, "Sanjay", "recruiter");
        JobPortal jobPortal = new JobPortal(user);
        ArrayList<String> skills = new ArrayList<>();
        skills.add("Java");
        skills.add("Python");
        jobPortal.createJob(1,"Gaussb", "SDE", "Bengaluru", skills, "Amazing Job", "Engineering");
        Job job = jobPortal.searchJobsById(1);
        assertNotNull(job);
    }
    @Test
    void testSearchJobByLocation(){
        User user = new User(1, "Sanjay", "recruiter");
        JobPortal jobPortal = new JobPortal(user);
        ArrayList<String> skills = new ArrayList<>();
        skills.add("Java");
        skills.add("Python");
        jobPortal.createJob(1,"Gaussb", "SDE", "Bengaluru", skills, "Amazing Job", "Engineering");
        jobPortal.createJob(1,"Gaussb", "SDE", "Gurugram", skills, "Amazing Job", "Engineering");
        ArrayList<Job> result = jobPortal.searchJobsByLocation("Gurugram");
        assertEquals(result.size(),1);
    }
    @Test
    void testJobSearchBySkills(){
        User user = new User(1, "Sanjay", "recruiter");
        JobPortal jobPortal = new JobPortal(user);
        ArrayList<String> skills = new ArrayList<>();
        skills.add("Python");
        skills.add("Java");
        jobPortal.createJob(1,"Gaussb", "SDE", "Bengaluru", skills, "Amazing Job", "Engineering");
        skills.clear();
        skills.add("Mongo");
        skills.add("Node");
        jobPortal.createJob(1,"Gaussb", "SDE", "Bengaluru", skills, "Amazing Job", "Engineering");
        String[] skillSearch = { "Java", "Mongo" };
        ArrayList<Job> result = jobPortal.searchJobBySkills(skillSearch);
        assertEquals(result.size(),2);
    }
    @Test
    void testJobCreationByUser(){
        User user = new User(1, "Sanjay", "user");
        JobPortal jobPortal = new JobPortal(user);
        ArrayList<String> skills = new ArrayList<>();
        skills.add("Python");
        skills.add("Java");
        boolean result = jobPortal.createJob(1,"Gaussb", "SDE", "Bengaluru", skills, "Amazing Job", "Engineering");
        assertFalse(result);
        user.setType("recruiter");
        result = jobPortal.createJob(1,"Gaussb", "SDE", "Bengaluru", skills, "Amazing Job", "Engineering");
        assertTrue(result);
    }
}
